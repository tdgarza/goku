'use strict';

jQuery.noConflict();
jQuery(document).ready(function ($) {

    // usage: 2
    $('#myForm').formToJson('.result-json-output');

});